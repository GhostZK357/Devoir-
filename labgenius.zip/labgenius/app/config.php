<?php
// Paramètres de connexion à la base de données
$host = "localhost";       // serveur MySQL
$db   = "labgenius";       // nom de la base de données
$user = "root";            // utilisateur MySQL (souvent 'root')
$pass = "";                // mot de passe MySQL (souvent vide sur XAMPP/WAMP)
$charset = "utf8mb4";      // encodage

// DSN pour PDO
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// Options PDO pour plus de sécurité et de debug
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

// Connexion PDO
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo "Erreur de connexion à la base : " . $e->getMessage();
    exit();
}
?>

<?php
$host = "localhost";
$db   = "labgenius";
$user = "root";       // utilisateur MySQL
$pass = "";           // mot de passe MySQL (souvent vide en local)
$charset = "utf8mb4";

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
    exit();
}
?>