// Sélection des éléments du formulaire et du message d'erreur
const form = document.querySelector("form");
const errorMsg = document.querySelector(".error");

// Au départ, on cache le message d'erreur
errorMsg.style.display = "none";

form.addEventListener("submit", function(e) {
    e.preventDefault(); // Empêche l'envoi du formulaire

    const email = form.email.value.trim();
    const password = form.password.value.trim();

    // Vérification basique
    if (email === "" || password === "") {
        errorMsg.textContent = "Tous les champs doivent être remplis ❌";
        errorMsg.style.display = "block";
        return;
    }

    if (!email.includes("@")) {
        errorMsg.textContent = "Email invalide ❌";
        errorMsg.style.display = "block";
        return;
    }

    // Pour la démo : afficher un message de connexion réussie
    alert(`Connexion simulée réussie pour ${email} ✅`);

    // Réinitialisation des champs
    form.reset();
    errorMsg.style.display = "none";
});