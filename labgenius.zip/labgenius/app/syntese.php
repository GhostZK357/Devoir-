<?php
// On peut utiliser cette section PHP pour récupérer et traiter la séquence ADN
$message = "";
$sequence = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["seqInput"])) {
        $sequence = trim($_POST["seqInput"]);

        // Ici tu peux ajouter le traitement de la séquence
        // Par exemple : validation ou génération d'un rapport simulé
        $message = "Séquence reçue : " . htmlspecialchars($sequence);
    } else {
        $message = "Veuillez saisir une séquence ADN ❌";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>LabGenius - Synthèse</title>
    <link rel="stylesheet" href="synthese.css">
</head>
<body>
    <!-- En-tête -->
    <header>
        <div class="logo">
            <img src="WhatsApp Image 2026-02-24 at 23.16.52.jpeg" alt="Logo LabGenius">
            <h1>LabGenius</h1>
        </div>
        <nav>
            <ul>
                <li><a href="app.php">Accueil</a></li>
                <li><a href="séquenceur.php">Séquenceur</a></li>
                <li><a href="synthese.php" class="active">Synthèse</a></li>
                <li><a href="connexion.php">Connexion</a></li>
            </ul>
        </nav>
    </header>

    <!-- Contenu principal -->
    <main>
        <section class="synthese">
            <h2>Machine de Synthèse</h2>
            <p>Saisissez une séquence ADN ou importez-la depuis l’éditeur :</p>

            <form id="synthForm" method="POST">
                <label for="seqInput">Séquence ADN :</label>
                <input type="text" id="seqInput" name="seqInput" placeholder="Ex: ATG-CGT-AAA-TGC" value="<?= htmlspecialchars($sequence) ?>">
                <button type="submit">Lancer la synthèse</button>
            </form>

            <!-- Message PHP -->
            <?php if($message): ?>
                <p class="status"><?= $message ?></p>
            <?php endif; ?>

            <div class="progress-container">
                <div id="progressBar"></div>
            </div>

            <p id="statusMsg">En attente...</p>
            <div id="rapport"></div>
        </section>
    </main>

    <script src="synthese.js"></script>
</body>
</html>