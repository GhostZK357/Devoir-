// Données simulées
const projets = ["Projet ADN Alpha", "Projet Mutation Beta"];
const sequences = ["ATG-CGT-AAA-TGC", "TTA-GGC-CCA-ATG"];

function chargerDashboard() {
    const ulProjets = document.getElementById("projets");
    const ulSeq = document.getElementById("sequences");

    projets.forEach(p => {
        const li = document.createElement("li");
        li.textContent = p;
        appliquerEffetHover(li);
        ulProjets.appendChild(li);
    });

    sequences.forEach(s => {
        const li = document.createElement("li");
        li.textContent = s;
        appliquerEffetHover(li);
        ulSeq.appendChild(li);
    });

    document.getElementById("nbSeq").textContent = sequences.length;
    document.getElementById("status").textContent = "En cours";
}

// Fonction pour changer la couleur au survol
function appliquerEffetHover(element) {
    element.addEventListener("mouseover", () => {
        element.style.color = "#2980b9"; // bleu professionnel
        element.style.cursor = "pointer";
    });
    element.addEventListener("mouseout", () => {
        element.style.color = "#333"; // couleur par défaut
    });
}

document.addEventListener("DOMContentLoaded", chargerDashboard);
