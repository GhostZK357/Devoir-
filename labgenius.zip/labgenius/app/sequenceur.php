<?php
// Exemple simple côté serveur
// Plus tard, on pourra sauvegarder les séquences modifiées dans une base MySQL

$sequence = "ATG-CGT-AAA-TGC";

// Exemple de fonction PHP pour mutation aléatoire
function mutationAleatoire($seq) {
    $bases = ['A','T','G','C'];
    $pos = rand(0, strlen($seq)-1);
    $seq[$pos] = $bases[array_rand($bases)];
    return $seq;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LabGenius — Séquenceur ADN</title>
    <link rel="stylesheet" href="sequenceur.css">
</head>

<body>

<!-- HEADER -->
<header class="header">

    <div class="logo">
        <img src="WhatsApp Image 2026-02-24 at 23.16.52.jpeg">
        <span>LabGenius</span>
    </div>

    <nav class="nav">
        <a href="app.html">Accueil</a>
        <a href="séquenceur.html" class="active">Séquenceur</a>
        <a href="syntese.html">Synthèse</a>
       <a href="connexion.html">Connexion</a>
    </nav>

</header>


<!-- MAIN -->
<main class="main">

    <section class="sequencer-container">

        <div class="sequencer-card">

            <h1>Éditeur de Génome</h1>

            <p class="subtitle">
                Modifiez et analysez vos séquences ADN avec précision scientifique
            </p>


            <!-- Séquence ADN -->
            <div class="sequence-display">

                <span id="sequence">
                    ATG-CGT-AAA-TGC
                </span>

            </div>


            <!-- FORM -->
            <form id="editForm" class="form">

                <div class="form-group">

                    <label>Position</label>

                    <input type="number" id="position" min="1" max="20" placeholder="Ex: 3">

                </div>


                <div class="form-group">

                    <label>Nouvelle base</label>

                    <select id="base">

                        <option>A</option>
                        <option>T</option>
                        <option>C</option>
                        <option>G</option>

                    </select>

                </div>


                <button type="submit" class="btn">

                    Modifier la séquence

                </button>

            </form>


            <!-- HISTORIQUE -->
            <div class="history">

                <h3>Historique</h3>

                <ul id="modifications">

                    <li class="empty">
                        Aucune modification pour le moment
                    </li>

                </ul>

            </div>


        </div>

    </section>

</main>


<!-- FOOTER -->
<footer class="footer">

    © 2026 LabGenius — Plateforme scientifique ADN

</footer>


<script src="sequencer.js"></script>

</body>
</html>