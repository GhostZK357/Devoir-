<?php
// Exemple simple côté serveur
$projets = ["Projet ADN Alpha", "Projet Mutation Beta"];
$sequences = ["ATG-CGT-AAA-TGC", "TTA-GGC-CCA-ATG"];

// Ici on pourrait connecter une base MySQL plus tard
// Exemple : SELECT * FROM sequences WHERE user_id = ...
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LabGenius - Tableau de bord</title>
    <link rel="stylesheet" href="app.css">
</head>

<body>

    <header class="header">
        <div class="logo">
            <img src="WhatsApp Image 2026-02-24 at 23.16.52.jpeg" alt="Logo LabGenius">
            <span>LabGenius</span>
        </div>

        <nav class="nav">
            <a href="app.html" class="active">Accueil</a>
            <a href="séquenceur.html">Séquenceur</a>
            <a href="syntese.html">Synthèse</a>
                <a href="connexion.html">Connexion</a>
        </nav>
    </header>


    <section class="hero">
        <div class="hero-overlay">
            <h1>Plateforme d'analyse génétique</h1>
            <p>Analysez, synthétisez et gérez vos séquences ADN avec précision</p>
        </div>
    </section>


    <main class="main">

        <section class="dashboard">

            <div class="dashboard-header">
                <h2>Tableau de bord</h2>
                <p>Bienvenue dans votre laboratoire numérique</p>
            </div>

            <div class="cards">

        
                <div class="card">
                    <div class="card-icon">
                        <img src="envelope.png">
                    </div>

                    <div class="card-content">
                        <h3>Projets</h3>
                        <p>Gérez vos projets scientifiques</p>
                    </div>
                </div>


                <div class="card">
                    <div class="card-icon">
                        <img src="dna.png">
                    </div>

                    <div class="card-content">
                        <h3>Séquences ADN</h3>
                        <p>Analysez vos données génétiques</p>
                    </div>
                </div>



                <div class="card stat-card">

                    <h3>Analyses réalisées</h3>

                    <div class="stat-number">
                        0
                    </div>

                    <p class="stat-description">
                        Total des analyses effectuées
                    </p>

                </div>

            </div>

        </section>

    </main>


    <footer class="footer">

        <p>
            © 2026 LabGenius — Plateforme scientifique numérique
        </p>

    </footer>

    <script src="app.js"></script>

</body>
</html>
