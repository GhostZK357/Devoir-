const form = document.getElementById("synthForm");
const progressBar = document.getElementById("progressBar");
const statusMsg = document.getElementById("statusMsg");
const rapport = document.getElementById("rapport");

const etapes = [
    "Analyse de la séquence ADN...",
    "Transcription en ARN...",
    "Validation biologique...",
    "Finalisation de la synthèse..."
];

// Fonction de transcription ADN → ARN
function transcrireADNversARN(seq) {
    return seq.replace(/T/g, "U"); // remplacer T par U
}

form.addEventListener("submit", function(e) {
    e.preventDefault();
    const seq = document.getElementById("seqInput").value.trim();

    if (seq === "") {
        alert("Veuillez entrer une séquence ADN !");
        return;
    }

    statusMsg.textContent = "Synthèse en cours...";
    progressBar.style.width = "0%";
    rapport.innerHTML = "";

    let progress = 0;
    let etapeIndex = 0;

    const interval = setInterval(() => {
        progress += 10;
        progressBar.style.width = progress + "%";

        if (progress % 25 === 0 && etapeIndex < etapes.length) {
            statusMsg.textContent = etapes[etapeIndex];
            etapeIndex++;
        }

        if (progress >= 100) {
            clearInterval(interval);

            const sequenceARN = transcrireADNversARN(seq);
            const complexite = seq.length;
            let tauxReussite = 100 - Math.floor(Math.random() * (complexite / 2));
            if (tauxReussite < 40) tauxReussite = 40;

            if (tauxReussite >= 70) {
                statusMsg.textContent = "Synthèse terminée";
                rapport.innerHTML = `
                    <h3>Rapport de Synthèse</h3>
                    <p><strong>Résultat :</strong> Succès </p>
                    <p><strong>Taux de réussite :</strong> ${tauxReussite}%</p>
                    <p><strong>Séquence ADN synthétisée :</strong> ${sequenceARN}</p>
                `;
            } else {
                statusMsg.textContent = "Synthèse échouée";
                rapport.innerHTML = `
                    <h3>Rapport de Synthèse</h3>
                    <p><strong>Résultat :</strong> Échec</p>
                    <p><strong>Taux de réussite :</strong> ${tauxReussite}%</p>
                    <p><strong>Séquence ARN proposée (non validée) :</strong> ${sequenceARN}</p>
                `;
            }
        }
    }, 500);
});
