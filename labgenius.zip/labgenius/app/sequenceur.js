let sequence = "ATG-CGT-AAA-TGC";
const sequenceBox = document.getElementById("sequence");
const form = document.getElementById("editForm");
const historyList = document.getElementById("modifications");

function afficherSequence() {
    sequenceBox.textContent = sequence;
}
form.addEventListener("submit", function(e) {
    e.preventDefault();

    const pos = parseInt(document.getElementById("position").value);
    const base = document.getElementById("base").value;

    if (!pos || pos < 1 || pos > sequence.length) {
        alert("Position invalide !");
        return;
    }
undefined,
    // Remplacer une seule lettre (y compris dans les blocs)
     ancienne = sequence;
    let seqArray = sequence.split("");
    seqArray[pos - 1] = base;
    sequence = seqArray.join("");

    afficherSequence();

    // Historique
    const li = document.createElement("li");
    li.textContent = `Position ${pos} : ${ancienne} → ${sequence}`;
    historyList.appendChild(li);
});

afficherSequence();
