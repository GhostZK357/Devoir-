<?php
session_start();
require "config.php";

echo '<pre>';
print_r($_POST);
echo '</pre>';


$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM utilisateurs WHERE email = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);

    $user = $stmt->fetch();

    if (!$user) {
        $message = "Email non trouvé ❌";
    } elseif (!password_verify($password, $user["mot_de_passe"])) {
        $message = "Mot de passe incorrect ❌";
    } else {
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["user_nom"] = $user["nom"];
        header("Location: index.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - LabGenius</title>
    <link rel="stylesheet" href="connexion.css">
</head>
<body>

<div class="login-container">

    <h1>🧬 LabGenius</h1>
    <h2>Connexion</h2>

    <?php if ($message != ""): ?>
        <p class="error-message"><?php echo $message; ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Mot de passe" required>
        <button type="submit">Se connecter</button>
    </form>

</div>
<script src="js/login.js"></script>
</body>
</html>